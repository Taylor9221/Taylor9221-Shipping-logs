from . import exceptions
from .serializable import Serializable


class Party(Serializable):
    def __init__(self, data=None):
        """
        Initialize a new shipment Party instance

        :type data: dict
        """
        self.name = ""
        self.address = ""
        super().__init__(data)

    def validate(self, data=None):
        """

        :type data: dict
        """
        for field_name, field_val in (data or self.__dict__).items():
            if not field_val:
                raise exceptions.ContentNotSet(
                    "No shipment party fields should be empty, as %s is" % field_name
                )
        super().validate(data)
