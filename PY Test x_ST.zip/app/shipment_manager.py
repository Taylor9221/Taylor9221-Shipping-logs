from .shipment import Shipment
from .rest_client import RestClient
import json


class ShipmentManager:
    api_url_base = "http://api.example.com/api/v1/package/"

    def __init__(self, code, client_secret):
        """
        Initialize the great ShipmentManager

        :param code: the authorization code to be provided to the RestClient
        :param client_secret: client_secret the secred passcode for the RestClient
        """
        self.base_url = "https://api.example.com/api/v1/package/"
        self.client = RestClient(self.base_url, code, client_secret)

    def _process_response(self, status, body):
        """
        Decode the response from the server

        :param status: int
        :param body: HTTPResponse
        :rtype: Shipment
        """
        json_body = json.loads(body)
        shipment = Shipment(json_body)
        return shipment

    def get_shipment_details(self, pkg_id):
        """
        get shipment details by id

        :param pkg_id: str
        :rtype: Shipment
        """
        status, body = self.client.get(self.base_url + pkg_id)
        return self._process_response(status, body)

    def ship_package(self, data):
        """
        Ship new package

        :param data: Shipment
        :rtype: Shipment
        """
        # Generate body        
        body = data.serialize()
        body.pop('id', None)

        # Create
        status, body = self.client.post(self.base_url, body )
        return self._process_response(status, body)

    def update_shipment(self, pkg_id, data):
        """
        Replace shipment details with the new one

        :param pkg_id: str
        :param data: Shipment
        """
        # Generate body
        status, body = self.client.put(self.base_url + pkg_id, data.serialize() )
        return self._process_response(status, body)

    def remove_shipment(self, pkg_id):
        """
        Remove a shipment from the platform

        :param pkg_id: str
        """
        # Generate body
        status, body = self.client.delete(self.base_url + pkg_id )
        return self._process_response(status, body)
