from .party import Party
from .serializable import Serializable


class Shipment(Serializable):
    def __init__(self, data=None):
        """
        Make a new Shipment object

        :param data: dict
        """
        self.id = ""
        self.sender = Party()
        self.recipient = Party()
        super().__init__(data)

    def validate(self, data=False):
        """

        :type data: dict
        """
        super().validate()
