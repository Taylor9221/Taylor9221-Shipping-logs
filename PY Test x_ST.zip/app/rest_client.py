from base64 import b64encode
from test.fake_responder.fakeresponder import FakeResponder 
import urllib
from .exceptions import InvalidIdFormat, InvalidContentData, ContentNotSet, NoDataFound
import time
import json
from oauthlib.oauth2 import WebApplicationClient, Client

REQUEST_GET = "GET"
REQUEST_POST = "POST"
REQUEST_PUT = "PUT"
REQUEST_DELETE = "DELETE"

class RestClient:
    client_id = "cfbf408c2556fbc45b38d82d969f11fe"

    token_path = "token"
    refresh_path = "refresh"

    scope = ["shipping"]

    encoding = "utf-8"
    default_content_type_header = {"Content-Type": "application/json"}
    default_auth_headers = {
        "Accept": "application/json",
        "Content-Type": ("application/x-www-form-urlencoded;charset=UTF-8"),
    }

    def __init__(self, base_url, code, client_secret, **kwargs):
        """
        Initialize a rest client with given credentials

        :param base_url: string
        :param code: dict
        """
        self.url_base = base_url
        self.basic_auth_header = {
            "Authorization": self._basic_auth_string(
                RestClient.client_id, client_secret
            )
        }


        # Generate fake responder
        self.token = {
            "token_type": "Bearer",
            "access_token": "asdfoiw37850234lkjsdfsdf",
            "refresh_token": "sldvafkjw34509s8dfsdf",
            "expires_in": 3600,
            "expires_at": time.time() + 3600,
        }
        initial_authorization_data = {
            "devskiller": {"scopes": ["shipping"], "token": self.token}
        }
        self.responder = FakeResponder(initial_authorization_data)

        # Generate Oauth access_token
        # oauthlib_client = WebApplicationClient(self.client_id)
        # post_body = oauthlib_client.prepare_request_body(
        #     client_secret=client_secret, code=code)
        # headers = {'Content-type': "application/json"}
        # req_path = f"{base_url}{self.token_path}"
        # req = urllib.request.Request(req_path, post_body.encode(), headers)
        # req.method = REQUEST_POST
        # response = self.responder.handle_request(req)

        # msg = response.read().decode()
        # data = json.loads(msg)
        # self.current_access_token = data['access_token']
        # self.current_refresh_token = data['refresh_token']

        
        (access_token, refresh_token) = self.fetch_token(url=base_url, client_secret=client_secret, code=code)
        
        self.jwt_auth_header = { "Authorization": f"Bearer {self.current_access_token}" }

        # Generate refresh_token
        self.refresh_token(url=base_url, refresh_token=self.current_refresh_token, auth=self.client_id)

        self.headers = RestClient.default_content_type_header
        self.token = None

    def _basic_auth_string(self, client_id, client_secret):        
        auth =  b64encode(str.encode(f'{client_id}:{client_secret}'))
        return f"Basic {auth.decode()}"



    def _request(self, request_type, path, data=None, additional_headers=None):
        """
        Make a request and send it to an endpoint

        :param additional_headers:
        :param request_type:
        :param path: string
        :param data: dict
        :return: int, string
        """
        
        headers = {'Content-type': "application/json"}        
        # Switch JWT or basic auth header
        #headers.update( self.jwt_auth_header )
        headers.update( self.basic_auth_header )

        req = urllib.request.Request(path, data, headers)
        req.method = request_type
        response = urllib.request.urlopen(req)
        msg = response.read().decode()
        if response.status != 200:
            if request_type == REQUEST_GET:
                raise NoDataFound()
            if request_type == REQUEST_POST:
                raise InvalidContentData()
        return (response.status, msg)

        

    def authorize_request(self, url, request_type, data, headers):
        """
        add authorization headers to request

        :param url:
        :param request_type:
        :param data:
        :param headers:
        """
        pass

    def fetch_token(self, url, client_secret, code):
        oauthlib_client = WebApplicationClient(self.client_id)
        post_body = oauthlib_client.prepare_request_body(
            client_secret=client_secret, code=code)
        headers = {'Content-type': "application/json"}
        req_path = f"{url}{self.token_path}"
        req = urllib.request.Request(req_path, post_body.encode(), headers)
        req.method = REQUEST_POST
        response = self.responder.handle_request(req)

        msg = response.read().decode()
        data = json.loads(msg)
        self.current_access_token = data['access_token']
        self.current_refresh_token = data['refresh_token']

        return (self.current_access_token, self.current_refresh_token)


    def refresh_token(self, url, body="", refresh_token=None, auth=None):
        # Generate refresh_token
        oauthlib_client = WebApplicationClient(self.client_id)      
        post_body = oauthlib_client.prepare_refresh_body(refresh_token=refresh_token, client_id=auth)
        headers = {'Content-type': "application/json"}
        req_path = f"{url}{self.refresh_path}"
        req = urllib.request.Request(req_path, post_body.encode(), headers)
        req.method = REQUEST_POST
        response = self.responder.handle_request(req)

        msg = response.read().decode()
        data = json.loads(msg)
        access_token = data['access_token']
        refresh_token = data['refresh_token']

        return ( access_token, refresh_token )

    def get(self, path=""):
        """
        make a GET request

        :param path: string
        :return: int, string

        """

        # Grab id and check
        id = path.split('/')
        if id[0] == 'T':
            num_id = id[-1]
            if num_id.isnumeric() == False:
                raise InvalidIdFormat()

        # Perform request
        return self._request(REQUEST_GET, path)

    def post(self, path, data, additional_headers=None):
        """make a POST request

        :param additional_headers:
        :param path:
        :param data:
        :return: int, string
        """
        # Check if data was set        
        if data is None:
            raise ContentNotSet()
        return self._request(REQUEST_POST, path, data, additional_headers)

    def put(self, path, data):
        """
        make a PUT request

        :param path:
        :param data:
        :return: int, string
        """
        # Check if data was set
        if data is None:
            raise ContentNotSet()
        return self._request(REQUEST_PUT, path, data)

    def delete(self, path):
        """
        make a DELETE request

        :param path: string
        :return: int, string
        """
        return self._request(REQUEST_DELETE, path)

    def _parse_token_body(self, r):
        pass
