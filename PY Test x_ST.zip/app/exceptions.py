class BaseException(Exception):
    """Base exception class"""


class InvalidIdFormat(BaseException):
    """Invalid Id format"""


class InvalidContentData(BaseException):
    """Invalid content data exception"""


class ContentNotSet(BaseException):
    """Content not set exception"""


class NoDataFound(BaseException):
    """ no data found """
