from setuptools import find_packages, setup


requirements = [
    "wheel==0.34.2",
    "oauthlib==3.1.0",
    "pytest<7,>=5",
    "pytest-timeout",
    "pytest-django",
]

setup(
    name="rest-client-for-shipping-company",
    version="1.0.0",
    author="Devskiller",
    author_email="support@devskiller.com",
    packages=find_packages(),
    install_requires=requirements,
    test_suite="test",
    tests_require=requirements,
    setup_requires=["pytest-runner"],
)
