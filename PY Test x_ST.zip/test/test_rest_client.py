"""Rest Client test module."""
import json
import time
import unittest
from os import path
from unittest import mock

from app.rest_client import RestClient
from test.fake_responder.fakeresponder import FakeResponder


class BasicRestClientTest(unittest.TestCase):
    def setUp(self):
        self.url = "https://api.example.com/api/v1/package/"
        self.code = "asdfoiw37850234lkjsdfsdf"
        self.secret = "5ebe2294ecd0e0f08eab7690d2a6ee69"
        self.token = {
            "token_type": "Bearer",
            "access_token": "asdfoiw37850234lkjsdfsdf",
            "refresh_token": "sldvafkjw34509s8dfsdf",
            "expires_in": 3600,
            "expires_at": time.time() + 3600,
        }

        self.client = RestClient(self.url, self.code, self.secret)
        initial_authorization_data = {
            "devskiller": {"scopes": ["shipping"], "token": self.token}
        }
        self.responder = FakeResponder(initial_authorization_data)



    @mock.patch("urllib.request.urlopen")
    def test_get(self, mock_urlopen):
        url = path.join(self.url, "package")
        mock_urlopen.side_effect = self._handle_request
        status, result = self.client.get(url)
        try:
            # test if data is JSON-parsable
            data = json.loads(result)
        except Exception as e:
            pass
        self.assertEqual(200, status)

    @mock.patch("urllib.request.urlopen")
    def test_get_with_id(self, mock_urlopen):
        url = path.join(self.url, "T10001")
        mock_urlopen.side_effect = self._handle_request
        status, result = self.client.get(url)
        self.assertEqual(200, status)

    @mock.patch("urllib.request.urlopen")
    def test_post(self, mock_urlopen):
        url = path.join(self.url, "create")
        new_entity = {
            "sender": {"name": "Carl Cricket", "address": "Fast Lane 1, 11150 Garage"},
            "recipient": {
                "name": "Max Rampage",
                "address": "Bright Street 99, 88888 Bumpy Hills",
            },
        }
        mock_urlopen.side_effect = self._handle_request
        status, result = self.client.post(url, new_entity)
        self.assertEqual(200, status)

    @mock.patch("urllib.request.urlopen")
    def test_put(self, mock_urlopen):
        id = "T10001"
        get_url = path.join(self.url, id)
        mock_urlopen.side_effect = self._handle_request
        _, result = self.client.get(get_url)
        entity = json.loads(result)
        entity["sender"]["name"] = "John McLoy"
        update_url = path.join(self.url, "update", id)
        status, result = self.client.put(update_url, entity)
        # self.assertEqual(8, result)
        self.assertEqual(200, status)

    @mock.patch("urllib.request.urlopen")
    def test_delete(self, mock_urlopen):
        url = path.join(self.url, "delete", "T10001")
        mock_urlopen.side_effect = self._handle_request
        status, result = self.client.delete(url)
        # self.assertEqual(2, result)
        self.assertEqual(200, status)

    def _handle_request(self, request):
        return self.responder.handle_request(request)
