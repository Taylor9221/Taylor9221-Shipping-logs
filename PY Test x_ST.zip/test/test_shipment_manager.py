import time
from unittest import TestCase, mock

from app.exceptions import NoDataFound
from app.party import Party
from app.shipment import Shipment
from app.shipment_manager import ShipmentManager
from test.fake_responder.fakeresponder import FakeResponder


class TestShipmentManager(TestCase):
    def setUp(self):
        self.code = "asdfoiw37850234lkjsdfsdf"
        self.secret = "5ebe2294ecd0e0f08eab7690d2a6ee69"
        self.token = {
            "token_type": "Bearer",
            "access_token": "asdfoiw37850234lkjsdfsdf",
            "refresh_token": "sldvafkjw34509s8dfsdf",
            "expires_in": 3600,
            "expires_at": time.time() + 3600,
        }
        self.shipment_manager = ShipmentManager(self.code, self.secret)
        initial_authorization_data = {
            "devskiller": {"scopes": ["shipping"], "token": self.token}
        }
        self.responder = FakeResponder(initial_authorization_data)

    @mock.patch("urllib.request.urlopen")
    def test_get_shipment_details(self, mock_urlopen):
        pkg_id = "T10001"
        mock_urlopen.side_effect = self._handle_request
        shipment = self.shipment_manager.get_shipment_details(pkg_id)
        self.assertEqual(shipment.id, pkg_id)
        self.assertIsInstance(shipment, Shipment)
        self.assertIsInstance(shipment.sender, Party)
        self.assertIsInstance(shipment.recipient, Party)

    @mock.patch("urllib.request.urlopen")
    def test_get_shipment_details_wrong_id(self, mock_urlopen):
        pkg_id = "R10002"
        mock_urlopen.side_effect = self._handle_request
        self.assertRaises(
            NoDataFound, self.shipment_manager.get_shipment_details, pkg_id
        )

    @mock.patch("urllib.request.urlopen")
    def test_ship_package(self, mock_urlopen):
        new_shipment = Shipment(
            {
                "sender": {
                    "name": "Carl Cricket",
                    "address": "Fast Lane 1, 11150 Garage",
                },
                "recipient": {
                    "name": "Max Rampage",
                    "address": "Bright Street 99, 88888 Bumpy Hills",
                },
            }
        )
        mock_urlopen.side_effect = self._handle_request
        stored_shipment = self.shipment_manager.ship_package(new_shipment)
        self.assertNotEqual(stored_shipment.id, "")
        self.assertIsInstance(stored_shipment, Shipment)
        self.assertIsInstance(stored_shipment.sender, Party)
        self.assertIsInstance(stored_shipment.recipient, Party)

    @mock.patch("urllib.request.urlopen")
    def test_update_shipment(self, mock_urlopen):
        pkg_id = "T10001"
        mock_urlopen.side_effect = self._handle_request
        shipment = self.shipment_manager.get_shipment_details(pkg_id)
        shipment.sender.name = "John McLoy"

        stored_shipment = self.shipment_manager.update_shipment(shipment.id, shipment)
        self.assertEqual(stored_shipment.id, pkg_id)
        self.assertIsInstance(stored_shipment, Shipment)
        self.assertIsInstance(stored_shipment.sender, Party)
        self.assertIsInstance(stored_shipment.recipient, Party)

    @mock.patch("urllib.request.urlopen")
    def test_remove_shipment(self, mock_urlopen):
        pkg_id = "T10001"
        mock_urlopen.side_effect = self._handle_request
        shipment = self.shipment_manager.remove_shipment(pkg_id)
        self.assertEqual(shipment.id, pkg_id)
        self.assertIsInstance(shipment, Shipment)
        self.assertIsInstance(shipment.sender, Party)
        self.assertIsInstance(shipment.recipient, Party)

    def _handle_request(self, request):
        return self.responder.handle_request(request)
